// prototypes for WinPAPI routines

// tests
extern int PAPI_StringsAndLabels(void);
extern int PAPI_Errors(void);
