//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WinPAPIShell.rc
//
#define IDS_STRING1                     1
#define IDC_MYICON                      2
#define IDPERFOMETEREX                  3
#define IDPERFOMETER                    4
#define IDWEB                           10
#define IDWEB2                          11
#define IDHELP2                         12
#define IDD_WINPAPISHELL_DIALOG         102
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WINPAPISHELL                107
#define IDI_SMALL                       108
#define IDC_WINPAPISHELL                109
#define IDR_MAINFRAME                   128
#define IDD_ABOUTBOX1                   135
#define IDB_BITMAP1                     136
#define IDD_ABOUTBOX2                   136
#define IDB_BITMAP2                     146
#define IDFORTRANEX                     1002
#define IDCEX                           1003
#define IDSMOKE                         1004
#define IDVERSION                       1005
#define IDDIAGNOSTIC                    1008
#define IDRDPMC                         1009
#define IDHELLO                         1010
#define IDHELLONUM                      1011
#define IDTASKSWITCH                    1012
#define IDEMPTY                         1013
#define IDDOLOOP                        1014
#define IDM_TEST_KERNEL                 32787
#define IDM_PAPI_TESTS                  32793
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
