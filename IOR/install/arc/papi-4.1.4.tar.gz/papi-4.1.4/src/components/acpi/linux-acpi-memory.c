#include "papi.h"
#include "papi_internal.h"

int
get_memory_info( PAPI_hw_info_t * mem_info )
{
	return PAPI_OK;
}
