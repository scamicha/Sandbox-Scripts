public class IpcInfo {
  public float real_time;
  public float proc_time;
  public long ins;
  public float ipc;
}
