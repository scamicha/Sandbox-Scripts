public class PAPI_inherit_option {
  public int inherit;

  public PAPI_inherit_option() {
    // do nothing
  }

  public PAPI_inherit_option(int i) {
    inherit=i;
  }

}
